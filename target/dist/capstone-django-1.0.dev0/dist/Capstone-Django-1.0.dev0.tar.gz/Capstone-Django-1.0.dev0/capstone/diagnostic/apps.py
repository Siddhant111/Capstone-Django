from django.apps import AppConfig


class DiagnosticConfig(AppConfig):
    name = 'diagnostic'
